//Declaración de variables numéricas
let entero=1357;
let decimal=135.7;
let cientifico=135e7;
let octal=0o1357;
let hexadecimal=0x1357;

//Para mostrar por consola
console.log("Numero entero: "+entero);
console.log("Número decial "+decimal);
console.log("Numero cientifico "+cientifico);
console.log("Número octal "+octal);
console.log("Número hexadecimal "+hexadecimal);