let respuesta;
do{
    respuesta=prompt("Introduce 1º apellido del primer presidente de la democracia")
}while(respuesta.toLowerCase!=="suarez")
