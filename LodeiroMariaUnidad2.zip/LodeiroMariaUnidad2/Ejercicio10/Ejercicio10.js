
let respuesta=prompt("Introduce nombre");
respuesta.toLowerCase;
if(respuesta=="luisa"||respuesta=="maria"||respuesta=="carlota"||respuesta=="martina"||respuesta=="claudia"){
    alert("Convocada");
}else alert("NO convocada");
