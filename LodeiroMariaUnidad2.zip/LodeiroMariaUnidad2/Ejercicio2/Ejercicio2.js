let nombre, apellido, edad, año;
nombre="Isa";
apellido="Lodeiro";
edad=20;
año=2004;
alert("Nombre: "+nombre);
alert("Nombre: "+nombre+"\n"+"apellido: "+apellido);
alert("Suma= "+(edad+año));
alert("Suma de todo= "+(nombre+apellido+edad+año));