let correcto=false;

let respuesta=prompt("Cual fué el primer presidente de la democracia Española?");
/*
do{
if (respuesta.toLowerCase=="adolfo"){
    respuesta=prompt("Te falta el apellido. ¿Cuál fue el primer presidente de la democracia española?")

}else alert("ERROR.intentelo de nuevo")  
}

*/
