let operacion1=(10==10);
alert("Operacion 1: "+operacion1);

let operacion2=(10===10);
alert("Operacion 2: "+operacion2);

let operacion3=(10===10.0);
alert("Operacion 3: "+operacion3);

let operacion4=("Laura"=="laura");
alert("Operacion 4: "+operacion4);

let operacion5=("Laura">"laura");
alert("Operacion 5: "+operacion5);

let operacion6=("Laura"<"laura");
alert("Operacion 6: "+operacion6);

let operacion7=("123"==123);
alert("Operacion 7: "+operacion7);

let operacion8=("123"===123);
alert("Operacion 8: "+operacion8);

let operacion9=(parseInt("123")===123);
alert("Operacion 9: "+operacion9);